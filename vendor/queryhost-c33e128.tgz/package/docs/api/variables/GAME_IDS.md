[**queryhost**](../README.md)

***

[queryhost](../README.md) / GAME\_IDS

# Variable: GAME\_IDS

> `const` **GAME\_IDS**: readonly \[`"a2s"`, `"dont-starve-together"`, `"rust"`, `"palworld"`, `"project-zomboid"`, `"7-days-to-die"`, `"dayz"`, `"valheim"`, `"minecraft-java"`, `"minecraft-bedrock"`, `"fivem"`, `"redm"`, `"satisfactory"`, `"vintage-story"`\]

Stable presentation order for supported games.
