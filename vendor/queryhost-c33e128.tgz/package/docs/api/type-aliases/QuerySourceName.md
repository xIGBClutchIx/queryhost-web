[**queryhost**](../README.md)

***

[queryhost](../README.md) / QuerySourceName

# Type Alias: QuerySourceName

> **QuerySourceName** = `"a2s-info"` \| `"a2s-player"` \| `"a2s-rules"` \| `"minecraft-srv"` \| `"minecraft-slp"` \| `"minecraft-query"` \| `"minecraft-bedrock-raknet"` \| `"fivem-info"` \| `"fivem-dynamic"` \| `"fivem-players"` \| `"redm-info"` \| `"redm-dynamic"` \| `"redm-players"` \| `"satisfactory-lightweight"` \| `"satisfactory-health"` \| `"vintage-story-query"`

Stable identifier for a protocol or discovery source used by a game profile.
