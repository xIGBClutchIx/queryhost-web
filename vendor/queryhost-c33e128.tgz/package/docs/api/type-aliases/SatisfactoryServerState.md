[**queryhost**](../README.md)

***

[queryhost](../README.md) / SatisfactoryServerState

# Type Alias: SatisfactoryServerState

> **SatisfactoryServerState** = `"idle"` \| `"loading"` \| `"playing"`

Lifecycle state returned by Satisfactory's lightweight status service.
