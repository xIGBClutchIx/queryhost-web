**queryhost**

***

# queryhost

## Interfaces

- [A2sData](interfaces/A2sData.md)
- [A2sPlayer](interfaces/A2sPlayer.md)
- [A2sRawData](interfaces/A2sRawData.md)
- [CfxData](interfaces/CfxData.md)
- [CfxPlayer](interfaces/CfxPlayer.md)
- [DayZData](interfaces/DayZData.md)
- [DayZMod](interfaces/DayZMod.md)
- [DayZRawData](interfaces/DayZRawData.md)
- [DontStarveTogetherData](interfaces/DontStarveTogetherData.md)
- [DontStarveTogetherPlayer](interfaces/DontStarveTogetherPlayer.md)
- [FiveMData](interfaces/FiveMData.md)
- [FiveMPlayer](interfaces/FiveMPlayer.md)
- [GameAliasMap](interfaces/GameAliasMap.md)
- [GameDataMap](interfaces/GameDataMap.md)
- [GameDefinition](interfaces/GameDefinition.md)
- [GameRawDataMap](interfaces/GameRawDataMap.md)
- [MinecraftBedrockData](interfaces/MinecraftBedrockData.md)
- [MinecraftJavaData](interfaces/MinecraftJavaData.md)
- [MinecraftMotd](interfaces/MinecraftMotd.md)
- [MinecraftPlugin](interfaces/MinecraftPlugin.md)
- [MinecraftSoftware](interfaces/MinecraftSoftware.md)
- [MinecraftSrvTarget](interfaces/MinecraftSrvTarget.md)
- [PalworldData](interfaces/PalworldData.md)
- [PalworldPlayer](interfaces/PalworldPlayer.md)
- [ProjectZomboidData](interfaces/ProjectZomboidData.md)
- [ProjectZomboidPlayer](interfaces/ProjectZomboidPlayer.md)
- [QueryError](interfaces/QueryError.md)
- [QueryFailure](interfaces/QueryFailure.md)
- [QuerySource](interfaces/QuerySource.md)
- [QuerySuccess](interfaces/QuerySuccess.md)
- [QueryWarning](interfaces/QueryWarning.md)
- [RedMData](interfaces/RedMData.md)
- [RedMPlayer](interfaces/RedMPlayer.md)
- [RustData](interfaces/RustData.md)
- [RustPlayer](interfaces/RustPlayer.md)
- [SatisfactoryData](interfaces/SatisfactoryData.md)
- [SatisfactoryHealth](interfaces/SatisfactoryHealth.md)
- [SatisfactoryRawData](interfaces/SatisfactoryRawData.md)
- [SatisfactorySubState](interfaces/SatisfactorySubState.md)
- [ServerInfo](interfaces/ServerInfo.md)
- [ServerPlayers](interfaces/ServerPlayers.md)
- [SevenDaysToDieData](interfaces/SevenDaysToDieData.md)
- [SevenDaysToDiePlayer](interfaces/SevenDaysToDiePlayer.md)
- [ValheimData](interfaces/ValheimData.md)
- [ValheimPlayer](interfaces/ValheimPlayer.md)
- [VintageStoryData](interfaces/VintageStoryData.md)

## Type Aliases

- [CanonicalGameId](type-aliases/CanonicalGameId.md)
- [GameAlias](type-aliases/GameAlias.md)
- [GameCapability](type-aliases/GameCapability.md)
- [GameId](type-aliases/GameId.md)
- [GameInputId](type-aliases/GameInputId.md)
- [GameRegistry](type-aliases/GameRegistry.md)
- [GameRuleMap](type-aliases/GameRuleMap.md)
- [QueryErrorCode](type-aliases/QueryErrorCode.md)
- [QueryInput](type-aliases/QueryInput.md)
- [QueryMode](type-aliases/QueryMode.md)
- [QueryResult](type-aliases/QueryResult.md)
- [QuerySourceName](type-aliases/QuerySourceName.md)
- [QuerySourceStatus](type-aliases/QuerySourceStatus.md)
- [QueryWarningCode](type-aliases/QueryWarningCode.md)
- [SatisfactoryServerState](type-aliases/SatisfactoryServerState.md)
- [SupportLevel](type-aliases/SupportLevel.md)

## Variables

- [GAME\_ALIASES](variables/GAME_ALIASES.md)
- [GAME\_IDS](variables/GAME_IDS.md)
- [GAME\_REGISTRY](variables/GAME_REGISTRY.md)

## Functions

- [canonicalGameId](functions/canonicalGameId.md)
- [getGameDefinition](functions/getGameDefinition.md)
- [isGameAlias](functions/isGameAlias.md)
- [isGameId](functions/isGameId.md)
- [isGameInputId](functions/isGameInputId.md)
- [listGames](functions/listGames.md)
- [query](functions/query.md)
