[**queryhost**](../README.md)

***

[queryhost](../README.md) / A2sPlayer

# Interface: A2sPlayer

One player returned by the generic A2S Player source.

## Properties

### durationSeconds

> `readonly` **durationSeconds**: `number`

***

### index

> `readonly` **index**: `number`

***

### name

> `readonly` **name**: `string`

***

### score

> `readonly` **score**: `number`
