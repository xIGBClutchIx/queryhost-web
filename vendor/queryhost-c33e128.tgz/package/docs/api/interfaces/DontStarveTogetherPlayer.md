[**queryhost**](../README.md)

***

[queryhost](../README.md) / DontStarveTogetherPlayer

# Interface: DontStarveTogetherPlayer

One player returned by Don't Starve Together's optional Steam A2S Player source.

## Properties

### durationSeconds

> `readonly` **durationSeconds**: `number`

***

### index

> `readonly` **index**: `number`

***

### name

> `readonly` **name**: `string`

***

### score

> `readonly` **score**: `number`
