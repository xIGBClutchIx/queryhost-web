[**queryhost**](../README.md)

***

[queryhost](../README.md) / CfxPlayer

# Interface: CfxPlayer

One player reported by a Cfx FXServer fixed players endpoint.

## Extended by

- [`FiveMPlayer`](FiveMPlayer.md)
- [`RedMPlayer`](RedMPlayer.md)

## Properties

### id

> `readonly` **id**: `number`

***

### name

> `readonly` **name**: `string`

***

### ping?

> `readonly` `optional` **ping?**: `number`
