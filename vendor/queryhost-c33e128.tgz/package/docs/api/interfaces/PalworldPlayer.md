[**queryhost**](../README.md)

***

[queryhost](../README.md) / PalworldPlayer

# Interface: PalworldPlayer

One player returned by Palworld's conditional Steam A2S Player source.

## Properties

### durationSeconds

> `readonly` **durationSeconds**: `number`

***

### index

> `readonly` **index**: `number`

***

### name

> `readonly` **name**: `string`

***

### score

> `readonly` **score**: `number`
