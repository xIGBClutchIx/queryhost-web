[**queryhost**](../README.md)

***

[queryhost](../README.md) / DayZRawData

# Interface: DayZRawData

Raw direct DayZ Rules retained separately from decoded paged metadata.

## Properties

### rules

> `readonly` **rules**: [`GameRuleMap`](../type-aliases/GameRuleMap.md)

Direct string-valued pairs; binary metadata pages are decoded under [DayZData](DayZData.md).
