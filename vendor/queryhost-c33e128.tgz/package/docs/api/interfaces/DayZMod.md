[**queryhost**](../README.md)

***

[queryhost](../README.md) / DayZMod

# Interface: DayZMod

One DayZ mod decoded from the paged server-browser metadata in A2S Rules.

## Properties

### hash

> `readonly` **hash**: `number`

Unsigned 32-bit short hash advertised by the server.

***

### name

> `readonly` **name**: `string`

***

### workshopId?

> `readonly` `optional` **workshopId?**: `string`

Decimal Steam Workshop item ID; omitted when the server advertises zero.
