[**queryhost**](../README.md)

***

[queryhost](../README.md) / SatisfactorySubState

# Interface: SatisfactorySubState

One recognized Satisfactory subsystem revision counter.

## Properties

### id

> `readonly` **id**: `number`

Protocol-defined subsystem ID from 0 through 7.

***

### version

> `readonly` **version**: `number`
