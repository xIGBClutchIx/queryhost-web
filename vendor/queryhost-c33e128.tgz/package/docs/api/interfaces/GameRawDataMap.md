[**queryhost**](../README.md)

***

[queryhost](../README.md) / GameRawDataMap

# Interface: GameRawDataMap

Associates implemented games with their untouched protocol payloads.

## Properties

### 7-days-to-die

> `readonly` **7-days-to-die**: [`A2sRawData`](A2sRawData.md)

***

### a2s

> `readonly` **a2s**: [`A2sRawData`](A2sRawData.md)

***

### dayz

> `readonly` **dayz**: [`DayZRawData`](DayZRawData.md)

***

### dont-starve-together

> `readonly` **dont-starve-together**: [`A2sRawData`](A2sRawData.md)

***

### fivem

> `readonly` **fivem**: `never`

***

### minecraft-bedrock

> `readonly` **minecraft-bedrock**: `never`

***

### minecraft-java

> `readonly` **minecraft-java**: `never`

***

### palworld

> `readonly` **palworld**: [`A2sRawData`](A2sRawData.md)

***

### project-zomboid

> `readonly` **project-zomboid**: [`A2sRawData`](A2sRawData.md)

***

### redm

> `readonly` **redm**: `never`

***

### rust

> `readonly` **rust**: [`A2sRawData`](A2sRawData.md)

***

### satisfactory

> `readonly` **satisfactory**: [`SatisfactoryRawData`](SatisfactoryRawData.md)

***

### valheim

> `readonly` **valheim**: `never`

***

### vintage-story

> `readonly` **vintage-story**: `never`
