[**queryhost**](../README.md)

***

[queryhost](../README.md) / SatisfactoryHealth

# Interface: SatisfactoryHealth

Health data returned by the credential-free HTTPS HealthCheck function.

## Properties

### health

> `readonly` **health**: `"healthy"` \| `"slow"`

***

### serverCustomData

> `readonly` **serverCustomData**: `string`

Empty means the vanilla server confirmed that it supplied no custom data.
