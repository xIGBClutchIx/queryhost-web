[**queryhost**](../README.md)

***

[queryhost](../README.md) / ValheimPlayer

# Interface: ValheimPlayer

One connection record reported by Valheim's optional A2S Player source.

## Properties

### durationSeconds

> `readonly` **durationSeconds**: `number`

***

### index

> `readonly` **index**: `number`

***

### name

> `readonly` **name**: `string`

Valheim's Steam backend commonly returns an empty name for privacy.

***

### score

> `readonly` **score**: `number`
