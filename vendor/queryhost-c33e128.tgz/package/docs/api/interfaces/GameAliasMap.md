[**queryhost**](../README.md)

***

[queryhost](../README.md) / GameAliasMap

# Interface: GameAliasMap

Alternate input spellings mapped to one stable game identity.

## Properties

### 7d2d

> `readonly` **7d2d**: `"7-days-to-die"`

***

### 7days-to-die

> `readonly` **7days-to-die**: `"7-days-to-die"`

***

### 7dtd

> `readonly` **7dtd**: `"7-days-to-die"`

***

### bedrock

> `readonly` **bedrock**: `"minecraft-bedrock"`

***

### dontstarvetogether

> `readonly` **dontstarvetogether**: `"dont-starve-together"`

***

### dst

> `readonly` **dst**: `"dont-starve-together"`

***

### five-m

> `readonly` **five-m**: `"fivem"`

***

### java

> `readonly` **java**: `"minecraft-java"`

***

### mc

> `readonly` **mc**: `"minecraft-java"`

***

### mc-bedrock

> `readonly` **mc-bedrock**: `"minecraft-bedrock"`

***

### mcbe

> `readonly` **mcbe**: `"minecraft-bedrock"`

***

### minecraft

> `readonly` **minecraft**: `"minecraft-java"`

***

### minecraft-bedrock-edition

> `readonly` **minecraft-bedrock-edition**: `"minecraft-bedrock"`

***

### minecraft-java-edition

> `readonly` **minecraft-java-edition**: `"minecraft-java"`

***

### projectzomboid

> `readonly` **projectzomboid**: `"project-zomboid"`

***

### pz

> `readonly` **pz**: `"project-zomboid"`

***

### rdr3

> `readonly` **rdr3**: `"redm"`

***

### red-m

> `readonly` **red-m**: `"redm"`

***

### seven-days-to-die

> `readonly` **seven-days-to-die**: `"7-days-to-die"`

***

### vintagestory

> `readonly` **vintagestory**: `"vintage-story"`

***

### vs

> `readonly` **vs**: `"vintage-story"`

***

### zomboid

> `readonly` **zomboid**: `"project-zomboid"`
