[**queryhost**](../README.md)

***

[queryhost](../README.md) / GameDataMap

# Interface: GameDataMap

Associates each game ID with its stable game-specific result shape.

Adding a game here forces the registry and callers using exhaustive switches to handle it.

## Properties

### 7-days-to-die

> `readonly` **7-days-to-die**: [`SevenDaysToDieData`](SevenDaysToDieData.md)

***

### a2s

> `readonly` **a2s**: [`A2sData`](A2sData.md)

***

### dayz

> `readonly` **dayz**: [`DayZData`](DayZData.md)

***

### dont-starve-together

> `readonly` **dont-starve-together**: [`DontStarveTogetherData`](DontStarveTogetherData.md)

***

### fivem

> `readonly` **fivem**: [`FiveMData`](FiveMData.md)

***

### minecraft-bedrock

> `readonly` **minecraft-bedrock**: [`MinecraftBedrockData`](MinecraftBedrockData.md)

***

### minecraft-java

> `readonly` **minecraft-java**: [`MinecraftJavaData`](MinecraftJavaData.md)

***

### palworld

> `readonly` **palworld**: [`PalworldData`](PalworldData.md)

***

### project-zomboid

> `readonly` **project-zomboid**: [`ProjectZomboidData`](ProjectZomboidData.md)

***

### redm

> `readonly` **redm**: [`RedMData`](RedMData.md)

***

### rust

> `readonly` **rust**: [`RustData`](RustData.md)

***

### satisfactory

> `readonly` **satisfactory**: [`SatisfactoryData`](SatisfactoryData.md)

***

### valheim

> `readonly` **valheim**: [`ValheimData`](ValheimData.md)

***

### vintage-story

> `readonly` **vintage-story**: [`VintageStoryData`](VintageStoryData.md)
